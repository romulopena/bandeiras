//função criar a dimensão da tela
function setup() {
  createCanvas(500, 350);
}
//função desenhar tela de fundo
function draw() {
  background(0,0,250);
  
  //primeiro retangulo
  fill(250,250,0);
  stroke(250,250,0);
  rect(0,175,500,350);
  
  //segundo retangulo
  fill(250,250,0);
  stroke(250,250,0);
  rect(0,175,500,350);
}